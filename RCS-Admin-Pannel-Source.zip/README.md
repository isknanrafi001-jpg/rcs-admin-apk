# RCS Admin Pannel Android source

This ZIP is intended to be uploaded directly to the GitHub repository as a single file named `RCS-Admin-Pannel-Source.zip`. Do not extract it locally.

Upload the separate workflow file as `.github/workflows/build-apk.yml`. That workflow will extract this ZIP during GitHub Actions and build the Android debug APK.

App label: RCS Admin Pannel
Admin URL: https://ruqyah-center-sirajganj.isknanrafi001.workers.dev/rakhi.html
