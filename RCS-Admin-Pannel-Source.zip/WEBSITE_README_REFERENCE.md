# Ruqyah Center Sirajganj — Manual Payment Submission Update

## Included files
- `index.html`, `style.css`, `script.js`: website and manual bKash/Nagad payment flow.
- `rakhi.html`, `admin.css`, `admin.js`: admin panel; payment transaction details appear inside the relevant application card.
- `03_manual_payment_admin.sql`: database migration to save customer Transaction IDs and allow Admin approval.
- `supabase-config.js`, `supabase-client.js`: existing Supabase public client configuration.
- Existing logo, representative photo, and session poster assets.

## Important: run the SQL first
1. Open Supabase Dashboard → SQL Editor.
2. Create a new query and paste/run `03_manual_payment_admin.sql`.
3. Run it only after the current schema and `02_fix_rpc_and_submission.sql` have already succeeded.
4. Confirm the query reports success before deploying the updated website.

## New manual payment workflow
1. Admin enables a service as `Manual Payment` and sets its fee in Admin → Service & Payment.
2. Customer submits the application. The database creates an application record and returns its internal UUID; the UUID is not displayed to the customer.
3. Customer selects bKash (shown first) or Nagad in the payment popup, sends the displayed amount to `01755-144882`, enters the Transaction ID, and presses Submit.
4. `submit_manual_payment` validates the application UUID and matching customer phone, rejects duplicate provider/transaction IDs, and saves the transaction to `public.payments`.
5. Admin → Applications displays provider, amount, Transaction ID, submission time, and `Pending — যাচাই প্রয়োজন` with Approve / Transaction ভুল actions.
6. Admin checks the actual payment account. Approve changes the payment and application payment status to `paid`; rejecting changes it to `failed`.

## Security notes
- Do not put a Supabase service-role key in website JavaScript.
- Public customers can only submit a manual payment through the validation RPC. They cannot approve it.
- Only authenticated users with an active `admin` or `super_admin` profile can run `admin_verify_manual_payment`.
- This is manual Send Money, not a live bKash/Nagad API gateway. The Transaction ID is not automatically proof that funds arrived.

## Deploy
After the SQL succeeds, upload all files together to the same Cloudflare static assets directory. Keep `index.html`, `rakhi.html`, JavaScript, CSS, `supabase-config.js`, and the image assets in the same directory. To add a link to the admin page in `index.html`, place `<a href="rakhi.html">Admin Panel</a>` where you want the link to appear (for example, in the footer). Hard-refresh the site after deployment.

The video HTML tag/player remains in `index.html`. If you want the video itself hosted with the site, copy `ruqyah-session.mp4` into the same directory on your PC before uploading.
